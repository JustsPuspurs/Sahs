import { j as jsxDevRuntimeExports } from './index-DgpyOq93.js';
import { a as dist } from './index-xOKW9rjh.js';

const Wrapper = ({ children }) => /* @__PURE__ */ jsxDevRuntimeExports.jsxDEV(
  dist.InertiaProvider,
  {
    initialPage: {
      component: "Login",
      props: {
        errors: {},
        auth: { user: null },
        flash: {}
      },
      url: "/",
      version: null
    },
    children
  },
  void 0,
  false,
  {
    fileName: "C:/xampp/htdocs/ceram/Sahs/Chess/chess_laravel/tests/components/Wrapper.jsx",
    lineNumber: 5,
    columnNumber: 3
  },
  undefined
);

export { Wrapper as default };
//# sourceMappingURL=Wrapper-Bzo8tb_S.js.map
