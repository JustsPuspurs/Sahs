import { j as jsxDevRuntimeExports } from './index-DgpyOq93.js';

const Hello = () => /* @__PURE__ */ jsxDevRuntimeExports.jsxDEV("div", { children: "Hello" }, void 0, false, {
  fileName: "C:/xampp/htdocs/ceram/Sahs/Chess/chess_laravel/resources/js/Hello.jsx",
  lineNumber: 4,
  columnNumber: 21
}, undefined);

export { Hello as default };
//# sourceMappingURL=Hello-C5O0Dkkf.js.map
